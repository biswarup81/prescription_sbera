<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="media/js/jquery-1.12.4.js"></script>
   <!-- Bootstrap -->
    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    <script src="bootstrap-3.3.7-dist/assets/js/docs.min.js"></script>
	<!-- jquery UI -->
	<script src="jquery/ui/jquery-ui.js"></script>
	<!-- jquery validator -->
	<script src="media/js/jquery.validate.js"></script>
	<script src ="js/makeprescription.js"></script>
	
   <!-- Datatable -->
   <script src="media/js/jquery.dataTables.js">
	</script>
	<script  src="media/js/dataTables.buttons.min.js">
	</script>
<script  src="media/js/buttons.flash.min.js">
	</script>
<script type="text/javascript" src="media/js/jszip.min.js">
	</script>
<script type="text/javascript" src="media/js/pdfmake.min.js">
	</script>
<script type="text/javascript" src="media/js/vfs_fonts.js">
	</script>
<script type="text/javascript" src="media/js/buttons.html5.min.js">
	</script>
<script type="text/javascript" src="media/js/buttons.print.min.js">
	</script>
<script src="ckeditor/ckeditor.js"></script>