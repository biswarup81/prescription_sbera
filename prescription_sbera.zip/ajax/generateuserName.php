<?php
include_once"../inc/datacon.php";
include '../classes/admin_class.php';

$input_name = $_GET['username'];

echo $input_name;
?>