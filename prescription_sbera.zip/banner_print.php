<?php 

	 if(isset($_SESSION['chamber_name'])) {
     include_once ("doc_header_print.php") ;
     
     }?>
 
<!--END of header-->