<div class="others">
<div class="other_headings"><!--<img src="images/Briefcase-Medical.png" />-->Others </div>
    <div class="inner_addiction">

    
        <div class="form-group"> 
        	<label for="addictions">Addictions</label>  
        	<div class="checkbox">
        	    <label><input type="checkbox" name="addictions" value="Nicotine"> Nicotine</label><label><input type="checkbox" name="addictions" value="Alcohol"> Alcohol</label>
        	 </div> 
        	<label for="family">Diabetic history</label>  
        	<div class="checkbox">
        	    <label><input type="checkbox" name="family" value="Father"> Father</label><label><input type="checkbox" name="family" value="Mother"> Mother</label>
        	    <label><input type="checkbox" name="family" value="Sibling"> Sibling</label>
        	 </div>
        </div>

    </div>
</div>