<div class="others">
<div class="other_headings"><!--<img src="images/Briefcase-Medical.png" />-->Others </div>
    <div class="inner_addiction">

    <!-- Get In Touch Starts -->
    
    
<div class="form-group"> 
	<label for="exampleInputEmail1">Addictions</label>  
	<div class="checkbox">
	    <label><input type="checkbox" name="addictions" value="Nicotine"> Nicotine</label><label><input type="checkbox" name="addictions" value="Alcohol"> Alcohol</label>
	 </div> 
	<label for="exampleInputEmail1">Diabetic history</label>  
	<div class="checkbox">
	    <label><input type="checkbox" name="family" value="Father"> Father</label><label><input type="checkbox" name="family" value="Mother"> Mother</label>
	    <label><input type="checkbox" name="family" value="Sibling"> Sibling</label>
	 </div>
</div>

<!-- Get In Touch Ends -->					
    </div>
</div>
<div class="others">
    <div class="other_headings"><!--<img src="images/Briefcase-Medical.png" />-->History </div>
    <div class="inner_history">

    <?php include_once 'pre_prescriptions.php';?>



<!-- Get In Touch Ends -->					
    </div>

</div>