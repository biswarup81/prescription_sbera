<?php include_once "./inc/datacon.php";
include_once "./inc/header.php"; ?>

    <?php include './inc/dashboard_topnav.php'; ?>

    <div class="container-fluid">
      <div class="row">
        <?php include './inc/dashboard_sidenav.php'; ?>
        

        </div>
    </div>

   <?php include_once './inc/footer.php';?>
  </body>
</html>