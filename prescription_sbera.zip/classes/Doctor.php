<?php
class Doctor{
	
}
?>